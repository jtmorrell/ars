###########################################################
## STAT 243 Final Project
## Adaptive Rejection Sampling Algorithm
##
## Date: 12/12/18
## Authors: Jonathan Morrell, Ziyang Zhou, Vincent Zijlmans
###########################################################

library('ars')

test_that("Dummy Test", {
  expect_equal(is.function(ars), TRUE)
})
