# ars
Adaptive Rejection Sampling - Final Project for UC Berkeley STAT 243